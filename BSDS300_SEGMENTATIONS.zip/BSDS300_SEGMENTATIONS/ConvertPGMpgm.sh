#! /bin/sh
# ConvertPGMpgm.sh script


cpt=0

###########
# Boucle  #
#####################################
for NameImg in *.pgm
do

#ImgWhitoutPathExt=${NameImg%.*}

#if [ ! \( -f ${ImgWhitoutPathExt}.ppm \) ]
#then
#echo $cpt  Manque ${ImgWhitoutPathExt}.ppm
#convert $NameImg ${ImgWhitoutPathExt}.ppm
#let cpt=cpt+1
#fi

convert $NameImg $NameImg

done


